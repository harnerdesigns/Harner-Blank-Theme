<?php get_header(); ?>
<?php include('loop.php');?>
<?php get_footer(); ?>