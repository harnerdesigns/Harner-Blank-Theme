<footer>
	&copy; Copyright <?php echo date("Y");?> <?php echo(bloginfo('title')); ?>
</footer>

<?php wp_footer(); ?>
</body>
</html>